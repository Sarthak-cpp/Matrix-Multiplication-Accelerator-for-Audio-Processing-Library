g++ measure.cpp -o measure.out;
./measure.out;
gnuplot gnuplotScript.p;

